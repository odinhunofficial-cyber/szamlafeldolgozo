-- Hozzáférés-kezelés: könyvelő meghívása a cégbe
-- Futtatás a 01-03 UTÁN: Supabase -> SQL Editor -> New query -> Run

-- Tulajdonos-ellenőrzés (security definer, hogy ne okozzon RLS-rekurziót)
create function public.is_owner(cid uuid)
returns boolean
language sql
security definer
stable
set search_path = public
as $$
  select exists (
    select 1 from public.company_members
    where company_id = cid and user_id = auth.uid() and role = 'owner'
  );
$$;

-- Közös cégben lévő felhasználók (hogy a tagok nevét lássuk)
create function public.shares_company_with(uid uuid)
returns boolean
language sql
security definer
stable
set search_path = public
as $$
  select exists (
    select 1
    from public.company_members a
    join public.company_members b on a.company_id = b.company_id
    where a.user_id = auth.uid() and b.user_id = uid
  );
$$;

create policy "profiles of co-members" on public.profiles
  for select using (public.shares_company_with(id));

-- Meghívók: az e-mail-címhez kötött függő hozzáférések
create table public.company_invites (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  email text not null check (email = lower(email)),
  role text not null default 'accountant' check (role in ('accountant')),
  invited_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  unique (company_id, email)
);

alter table public.company_invites enable row level security;

create policy "invites read" on public.company_invites
  for select using (public.is_member(company_id));
create policy "invites insert" on public.company_invites
  for insert with check (public.is_owner(company_id) and invited_by = auth.uid());
create policy "invites delete" on public.company_invites
  for delete using (public.is_owner(company_id));

-- A tulajdonos eltávolíthatja a könyvelőt (magát a tulajdonost nem)
create policy "owner removes accountants" on public.company_members
  for delete using (public.is_owner(company_id) and role = 'accountant');
