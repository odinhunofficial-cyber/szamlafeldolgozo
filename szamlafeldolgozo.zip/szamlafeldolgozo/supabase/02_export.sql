-- Export-kompatibilitás: konfigurálható exportprofilok
-- Futtatás a schema.sql UTÁN: Supabase -> SQL Editor -> New query -> Run

-- Az eredeti NAV XML megőrzése (sok könyvelőprogram közvetlenül tudja importálni)
alter table public.invoices add column if not exists raw_xml text;

-- Egy exportprofil = egy könyvelőprogram elvárt fájlformátuma
create table public.export_profiles (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  name text not null,                       -- pl. "Kulcs-Soft import"
  format text not null default 'csv' check (format in ('csv', 'xlsx')),
  delimiter text not null default ';',
  decimal_separator text not null default ',',
  date_format text not null default 'YYYY-MM-DD',
  encoding text not null default 'utf-8' check (encoding in ('utf-8', 'windows-1250')),
  -- oszlopok sorrendje és elnevezése, pl.:
  -- [{"header": "Számlaszám", "field": "invoice_number"},
  --  {"header": "Bruttó", "field": "gross_amount"}]
  column_mapping jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now()
);

alter table public.export_profiles enable row level security;

create policy "export profiles read" on public.export_profiles
  for select using (public.is_member(company_id));
create policy "export profiles insert" on public.export_profiles
  for insert with check (public.is_member(company_id));
create policy "export profiles update" on public.export_profiles
  for update using (public.is_member(company_id));
create policy "export profiles delete" on public.export_profiles
  for delete using (public.is_member(company_id));
