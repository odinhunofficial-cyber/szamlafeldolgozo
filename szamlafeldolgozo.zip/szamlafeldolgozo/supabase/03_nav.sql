-- NAV-modul: környezet, adószám és utolsó lekérdezés a hitelesítő adatokhoz
-- Futtatás a schema.sql és a schema_02_export.sql UTÁN.

alter table public.nav_credentials
  add column if not exists environment text not null default 'test'
    check (environment in ('test', 'prod')),
  add column if not exists tax_number text,
  add column if not exists last_synced_at timestamptz;

-- A cserekulcsra csak számlabeküldéshez lenne szükség, lekérdezéshez nem
alter table public.nav_credentials alter column exchange_key_enc drop not null;
