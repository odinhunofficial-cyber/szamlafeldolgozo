-- MINDEN EGYBEN: futtasd egyszer a Supabase SQL Editorban (új, üres projekten).

-- ===== supabase/01_schema.sql =====
-- Számlafeldolgozó MVP: alapséma (Supabase / Postgres)
-- Futtatás: Supabase Dashboard -> SQL Editor -> New query -> beillesztés -> Run

-- ========== Táblák ==========

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  created_at timestamptz not null default now()
);

create table public.companies (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  tax_number text,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now()
);

-- Ki fér hozzá melyik céghez: vállalkozó (owner) vagy könyvelő (accountant)
create table public.company_members (
  company_id uuid not null references public.companies(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  role text not null check (role in ('owner', 'accountant')),
  primary key (company_id, user_id)
);

create table public.invoices (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  source text not null check (source in ('nav', 'upload')),
  direction text not null check (direction in ('outgoing', 'incoming')),
  invoice_number text,
  issue_date date,
  supplier_name text,
  supplier_tax_number text,
  customer_name text,
  customer_tax_number text,
  net_amount numeric(14, 2),
  vat_amount numeric(14, 2),
  gross_amount numeric(14, 2),
  currency text not null default 'HUF',
  category text,
  status text not null default 'new' check (status in ('new', 'reviewed', 'exported')),
  file_path text,
  raw jsonb,
  created_at timestamptz not null default now(),
  unique (company_id, direction, invoice_number)
);

create index invoices_company_date_idx on public.invoices (company_id, issue_date desc);

-- NAV technikai felhasználó adatai: titkosítva, CSAK szerveroldalról (service role) érhető el
create table public.nav_credentials (
  company_id uuid primary key references public.companies(id) on delete cascade,
  login_enc text not null,
  password_enc text not null,
  signature_key_enc text not null,
  exchange_key_enc text not null,
  updated_at timestamptz not null default now()
);

-- ========== Automatikus profil regisztrációkor ==========

create function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, new.raw_user_meta_data ->> 'full_name');
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ========== Jogosultságok (Row Level Security) ==========

create function public.is_member(cid uuid)
returns boolean
language sql
security definer
stable
set search_path = public
as $$
  select exists (
    select 1 from public.company_members
    where company_id = cid and user_id = auth.uid()
  );
$$;

alter table public.profiles enable row level security;
alter table public.companies enable row level security;
alter table public.company_members enable row level security;
alter table public.invoices enable row level security;
alter table public.nav_credentials enable row level security;
-- nav_credentials: szándékosan nincs policy, így a kliens nem fér hozzá

create policy "own profile read" on public.profiles
  for select using (id = auth.uid());
create policy "own profile update" on public.profiles
  for update using (id = auth.uid());

create policy "companies read" on public.companies
  for select using (public.is_member(id) or created_by = auth.uid());
create policy "companies insert" on public.companies
  for insert with check (created_by = auth.uid());

create policy "members read" on public.company_members
  for select using (user_id = auth.uid() or public.is_member(company_id));
create policy "creator adds self as owner" on public.company_members
  for insert with check (
    user_id = auth.uid()
    and role = 'owner'
    and exists (
      select 1 from public.companies c
      where c.id = company_id and c.created_by = auth.uid()
    )
  );

create policy "invoices read" on public.invoices
  for select using (public.is_member(company_id));
create policy "invoices insert" on public.invoices
  for insert with check (public.is_member(company_id));
create policy "invoices update" on public.invoices
  for update using (public.is_member(company_id));

-- ========== Fájltárolás (feltöltött számlák) ==========
-- Útvonal-konvenció: <company_id>/<fájlnév>

insert into storage.buckets (id, name, public)
values ('invoice-files', 'invoice-files', false)
on conflict (id) do nothing;

create policy "members read invoice files" on storage.objects
  for select using (
    bucket_id = 'invoice-files'
    and public.is_member(((storage.foldername(name))[1])::uuid)
  );

create policy "members upload invoice files" on storage.objects
  for insert with check (
    bucket_id = 'invoice-files'
    and public.is_member(((storage.foldername(name))[1])::uuid)
  );

-- ===== supabase/02_export.sql =====
-- Export-kompatibilitás: konfigurálható exportprofilok
-- Futtatás a schema.sql UTÁN: Supabase -> SQL Editor -> New query -> Run

-- Az eredeti NAV XML megőrzése (sok könyvelőprogram közvetlenül tudja importálni)
alter table public.invoices add column if not exists raw_xml text;

-- Egy exportprofil = egy könyvelőprogram elvárt fájlformátuma
create table public.export_profiles (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  name text not null,                       -- pl. "Kulcs-Soft import"
  format text not null default 'csv' check (format in ('csv', 'xlsx')),
  delimiter text not null default ';',
  decimal_separator text not null default ',',
  date_format text not null default 'YYYY-MM-DD',
  encoding text not null default 'utf-8' check (encoding in ('utf-8', 'windows-1250')),
  -- oszlopok sorrendje és elnevezése, pl.:
  -- [{"header": "Számlaszám", "field": "invoice_number"},
  --  {"header": "Bruttó", "field": "gross_amount"}]
  column_mapping jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now()
);

alter table public.export_profiles enable row level security;

create policy "export profiles read" on public.export_profiles
  for select using (public.is_member(company_id));
create policy "export profiles insert" on public.export_profiles
  for insert with check (public.is_member(company_id));
create policy "export profiles update" on public.export_profiles
  for update using (public.is_member(company_id));
create policy "export profiles delete" on public.export_profiles
  for delete using (public.is_member(company_id));

-- ===== supabase/03_nav.sql =====
-- NAV-modul: környezet, adószám és utolsó lekérdezés a hitelesítő adatokhoz
-- Futtatás a schema.sql és a schema_02_export.sql UTÁN.

alter table public.nav_credentials
  add column if not exists environment text not null default 'test'
    check (environment in ('test', 'prod')),
  add column if not exists tax_number text,
  add column if not exists last_synced_at timestamptz;

-- A cserekulcsra csak számlabeküldéshez lenne szükség, lekérdezéshez nem
alter table public.nav_credentials alter column exchange_key_enc drop not null;

-- ===== supabase/04_access.sql =====
-- Hozzáférés-kezelés: könyvelő meghívása a cégbe
-- Futtatás a 01-03 UTÁN: Supabase -> SQL Editor -> New query -> Run

-- Tulajdonos-ellenőrzés (security definer, hogy ne okozzon RLS-rekurziót)
create function public.is_owner(cid uuid)
returns boolean
language sql
security definer
stable
set search_path = public
as $$
  select exists (
    select 1 from public.company_members
    where company_id = cid and user_id = auth.uid() and role = 'owner'
  );
$$;

-- Közös cégben lévő felhasználók (hogy a tagok nevét lássuk)
create function public.shares_company_with(uid uuid)
returns boolean
language sql
security definer
stable
set search_path = public
as $$
  select exists (
    select 1
    from public.company_members a
    join public.company_members b on a.company_id = b.company_id
    where a.user_id = auth.uid() and b.user_id = uid
  );
$$;

create policy "profiles of co-members" on public.profiles
  for select using (public.shares_company_with(id));

-- Meghívók: az e-mail-címhez kötött függő hozzáférések
create table public.company_invites (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  email text not null check (email = lower(email)),
  role text not null default 'accountant' check (role in ('accountant')),
  invited_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  unique (company_id, email)
);

alter table public.company_invites enable row level security;

create policy "invites read" on public.company_invites
  for select using (public.is_member(company_id));
create policy "invites insert" on public.company_invites
  for insert with check (public.is_owner(company_id) and invited_by = auth.uid());
create policy "invites delete" on public.company_invites
  for delete using (public.is_owner(company_id));

-- A tulajdonos eltávolíthatja a könyvelőt (magát a tulajdonost nem)
create policy "owner removes accountants" on public.company_members
  for delete using (public.is_owner(company_id) and role = 'accountant');

