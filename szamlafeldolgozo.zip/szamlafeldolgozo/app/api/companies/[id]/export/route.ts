import type { NextRequest } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { buildCsv, buildXlsx } from "@/lib/export/build";
import type { ExportProfile } from "@/lib/export/csv";
import type { InvoiceRow } from "@/lib/export/fields";

export const maxDuration = 60;

function text(message: string, status: number) {
  return new Response(message, { status, headers: { "Content-Type": "text/plain; charset=utf-8" } });
}

export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const search = request.nextUrl.searchParams;
  const profileId = search.get("profile") ?? "";
  const onlyNew = search.get("scope") === "new";
  const mark = search.get("mark") === "1";

  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return text("Jelentkezz be.", 401);

  // A Row Level Security miatt csak a saját cég profilja és számlái jönnek vissza
  const { data: profile } = await supabase
    .from("export_profiles")
    .select("format, delimiter, decimal_separator, date_format, encoding, column_mapping")
    .eq("id", profileId)
    .eq("company_id", id)
    .maybeSingle();
  if (!profile) return text("Az exportprofil nem található.", 404);

  let query = supabase
    .from("invoices")
    .select(
      "id, invoice_number, issue_date, direction, status, supplier_name, supplier_tax_number, customer_name, customer_tax_number, net_amount, vat_amount, gross_amount, currency, category"
    )
    .eq("company_id", id)
    .order("issue_date", { ascending: true })
    .limit(10000);
  if (onlyNew) query = query.neq("status", "exported");

  const { data: invoices, error } = await query;
  if (error) return text("Az adatok lekérdezése nem sikerült.", 500);
  if (!invoices || invoices.length === 0) return text("Nincs exportálható számla a kiválasztott szűréssel.", 404);

  const exportProfile = profile as ExportProfile;
  const rows = invoices as InvoiceRow[];

  const isXlsx = exportProfile.format === "xlsx";
  const body = isXlsx ? await buildXlsx(rows, exportProfile) : buildCsv(rows, exportProfile);

  if (mark) {
    const ids = invoices.filter((i) => i.status !== "exported").map((i) => i.id);
    for (let i = 0; i < ids.length; i += 200) {
      await supabase.from("invoices").update({ status: "exported" }).in("id", ids.slice(i, i + 200));
    }
  }

  const day = new Date().toISOString().slice(0, 10);
  const contentType = isXlsx
    ? "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    : `text/csv; charset=${exportProfile.encoding === "windows-1250" ? "windows-1250" : "utf-8"}`;

  return new Response(body as BodyInit, {
    headers: {
      "Content-Type": contentType,
      "Content-Disposition": `attachment; filename="szamlak-${day}.${isXlsx ? "xlsx" : "csv"}"`,
      "Cache-Control": "no-store",
    },
  });
}
