"use client";

import { useActionState, useState } from "react";
import { login, signup } from "./actions";
import type { FormState } from "@/lib/state";

export default function LoginPage() {
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [loginState, loginAction, loginPending] = useActionState<FormState, FormData>(login, {});
  const [signupState, signupAction, signupPending] = useActionState<FormState, FormData>(signup, {});

  return (
    <main className="auth">
      <h1>Számlafeldolgozó</h1>
      <p className="lead">Számlák egy helyen a vállalkozónak és a könyvelőnek.</p>

      <div className="panel">
        <div className="tabs" role="tablist">
          <button type="button" role="tab" className="tab" aria-selected={mode === "login"} onClick={() => setMode("login")}>
            Bejelentkezés
          </button>
          <button type="button" role="tab" className="tab" aria-selected={mode === "signup"} onClick={() => setMode("signup")}>
            Regisztráció
          </button>
        </div>

        {mode === "login" ? (
          <form action={loginAction} className="fields">
            <label>
              E-mail-cím
              <input name="email" type="email" autoComplete="email" required />
            </label>
            <label>
              Jelszó
              <input name="password" type="password" autoComplete="current-password" required />
            </label>
            {loginState.error && <p className="notice error" role="alert">{loginState.error}</p>}
            <button className="btn" disabled={loginPending}>Bejelentkezés</button>
          </form>
        ) : (
          <form action={signupAction} className="fields">
            <label>
              Név
              <input name="full_name" type="text" autoComplete="name" required />
            </label>
            <label>
              E-mail-cím
              <input name="email" type="email" autoComplete="email" required />
            </label>
            <label>
              Jelszó (legalább 8 karakter)
              <input name="password" type="password" autoComplete="new-password" minLength={8} required />
            </label>
            {signupState.error && <p className="notice error" role="alert">{signupState.error}</p>}
            {signupState.info && <p className="notice info" role="status">{signupState.info}</p>}
            <button className="btn" disabled={signupPending}>Regisztráció</button>
          </form>
        )}
      </div>
    </main>
  );
}
