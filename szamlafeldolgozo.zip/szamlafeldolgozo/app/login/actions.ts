"use server";

import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import type { FormState } from "@/lib/state";

export async function login(_prev: FormState, formData: FormData): Promise<FormState> {
  const supabase = await createClient();
  const { error } = await supabase.auth.signInWithPassword({
    email: String(formData.get("email") ?? "").trim(),
    password: String(formData.get("password") ?? ""),
  });

  if (error) return { error: "Hibás e-mail-cím vagy jelszó." };
  redirect("/companies");
}

export async function signup(_prev: FormState, formData: FormData): Promise<FormState> {
  const supabase = await createClient();
  const { data, error } = await supabase.auth.signUp({
    email: String(formData.get("email") ?? "").trim(),
    password: String(formData.get("password") ?? ""),
    options: { data: { full_name: String(formData.get("full_name") ?? "").trim() } },
  });

  if (error) return { error: `A regisztráció nem sikerült: ${error.message}` };
  if (!data.session) {
    return { info: "Megerősítő e-mailt küldtünk. Kattints a benne lévő linkre, utána jelentkezz be." };
  }
  redirect("/companies");
}

export async function logout() {
  const supabase = await createClient();
  await supabase.auth.signOut();
  redirect("/login");
}
