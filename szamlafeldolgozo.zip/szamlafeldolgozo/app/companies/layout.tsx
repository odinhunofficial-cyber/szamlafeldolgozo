import Link from "next/link";
import type { ReactNode } from "react";
import { createClient } from "@/lib/supabase/server";
import { logout } from "../login/actions";

export default async function AppLayout({ children }: { children: ReactNode }) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  return (
    <>
      <header className="topbar">
        <div className="topbar-inner">
          <Link href="/companies" className="brand">Számlafeldolgozó</Link>
          <div className="user">
            <span>{user?.email}</span>
            <form action={logout}>
              <button className="btn quiet small">Kijelentkezés</button>
            </form>
          </div>
        </div>
      </header>
      <div className="page">{children}</div>
    </>
  );
}
