import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { claimInvites } from "@/lib/invites";
import CreateCompanyForm from "./create-company-form";

export default async function CompaniesPage() {
  const supabase = await createClient();

  // Ha a felhasználót meghívták egy cégbe, itt kap hozzáférést (a lista lekérdezése előtt)
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (user) await claimInvites(user);

  const { data: companies } = await supabase
    .from("companies")
    .select("id, name, tax_number")
    .order("created_at", { ascending: false });

  return (
    <div className="stack">
      <div>
        <h1>Cégek</h1>
        <p className="lead">Válaszd ki a céget, vagy vegyél fel egy újat.</p>
      </div>

      {companies && companies.length > 0 ? (
        <ul className="company-list">
          {companies.map((c) => (
            <li key={c.id}>
              <Link href={`/companies/${c.id}`}>
                <span>{c.name}</span>
                <span className="tax">{c.tax_number ?? ""}</span>
              </Link>
            </li>
          ))}
        </ul>
      ) : (
        <p className="lead">Még nincs cég felvéve.</p>
      )}

      <section className="panel">
        <h2>Új cég</h2>
        <CreateCompanyForm />
      </section>
    </div>
  );
}
