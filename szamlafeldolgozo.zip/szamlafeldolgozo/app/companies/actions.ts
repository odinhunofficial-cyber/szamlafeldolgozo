"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import type { FormState } from "@/lib/state";

export async function createCompany(_prev: FormState, formData: FormData): Promise<FormState> {
  const name = String(formData.get("name") ?? "").trim();
  const taxNumber = String(formData.get("tax_number") ?? "").trim();

  if (!name) return { error: "Add meg a cég nevét." };

  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: company, error } = await supabase
    .from("companies")
    .insert({ name, tax_number: taxNumber || null, created_by: user.id })
    .select("id")
    .single();

  if (error || !company) return { error: "A céget nem sikerült létrehozni. Próbáld újra." };

  const { error: memberError } = await supabase
    .from("company_members")
    .insert({ company_id: company.id, user_id: user.id, role: "owner" });

  if (memberError) return { error: "A céget létrehoztuk, de a hozzáférést nem sikerült beállítani." };

  revalidatePath("/companies");
  redirect(`/companies/${company.id}`);
}
