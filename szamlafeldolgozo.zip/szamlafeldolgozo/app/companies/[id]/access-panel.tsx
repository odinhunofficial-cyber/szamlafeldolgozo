import { removeMember, revokeInvite } from "./access-actions";
import InviteForm from "./invite-form";

type Member = { user_id: string; role: string; name: string | null };
type Invite = { id: string; email: string };

const ROLE: Record<string, string> = { owner: "Tulajdonos", accountant: "Könyvelő" };

export default function AccessPanel({
  companyId,
  isOwner,
  members,
  invites,
}: {
  companyId: string;
  isOwner: boolean;
  members: Member[];
  invites: Invite[];
}) {
  return (
    <section className="panel">
      <h2>Hozzáférés</h2>

      <ul className="profile-list">
        {members.map((m) => (
          <li key={m.user_id}>
            <span>
              {m.name || "Névtelen felhasználó"} <span className="chip">{ROLE[m.role] ?? m.role}</span>
            </span>
            {isOwner && m.role === "accountant" && (
              <form action={removeMember}>
                <input type="hidden" name="company_id" value={companyId} />
                <input type="hidden" name="user_id" value={m.user_id} />
                <button className="btn quiet small">Eltávolítás</button>
              </form>
            )}
          </li>
        ))}
      </ul>

      {invites.length > 0 && (
        <>
          <h3>Függő meghívók</h3>
          <ul className="profile-list">
            {invites.map((i) => (
              <li key={i.id}>
                <span>{i.email}</span>
                {isOwner && (
                  <form action={revokeInvite}>
                    <input type="hidden" name="company_id" value={companyId} />
                    <input type="hidden" name="invite_id" value={i.id} />
                    <button className="btn quiet small">Visszavonás</button>
                  </form>
                )}
              </li>
            ))}
          </ul>
        </>
      )}

      {isOwner && (
        <details>
          <summary>Könyvelő meghívása</summary>
          <InviteForm companyId={companyId} />
        </details>
      )}
    </section>
  );
}
