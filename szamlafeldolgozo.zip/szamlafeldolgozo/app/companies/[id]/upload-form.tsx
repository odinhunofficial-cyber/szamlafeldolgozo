"use client";

import { useRef, useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { processUpload } from "./upload-actions";

type Item = {
  name: string;
  status: "queued" | "uploading" | "reading" | "done" | "error";
  message?: string;
};

const LABEL: Record<Item["status"], string> = {
  queued: "Várakozik",
  uploading: "Feltöltés…",
  reading: "Kiolvasás…",
  done: "Kész",
  error: "Hiba",
};

const CHIP: Record<Item["status"], string> = {
  queued: "",
  uploading: "new",
  reading: "new",
  done: "reviewed",
  error: "err",
};

const MAX_PDF = 10 * 1024 * 1024;
const MAX_IMAGE = 5 * 1024 * 1024;

export default function UploadForm({ companyId }: { companyId: string }) {
  const router = useRouter();
  const inputRef = useRef<HTMLInputElement>(null);
  const [items, setItems] = useState<Item[]>([]);
  const [busy, setBusy] = useState(false);

  const setItem = (i: number, patch: Partial<Item>) =>
    setItems((prev) => prev.map((it, idx) => (idx === i ? { ...it, ...patch } : it)));

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const files = Array.from(inputRef.current?.files ?? []);
    if (files.length === 0) return;

    setBusy(true);
    setItems(files.map((f) => ({ name: f.name, status: "queued" })));
    const supabase = createClient();

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const isPdf = file.type === "application/pdf" || file.name.toLowerCase().endsWith(".pdf");

      if (file.size > (isPdf ? MAX_PDF : MAX_IMAGE)) {
        setItem(i, { status: "error", message: isPdf ? "A PDF legfeljebb 10 MB lehet." : "A kép legfeljebb 5 MB lehet." });
        continue;
      }

      setItem(i, { status: "uploading" });
      const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, "_");
      const path = `${companyId}/${crypto.randomUUID()}_${safeName}`;
      const { error } = await supabase.storage
        .from("invoice-files")
        .upload(path, file, { contentType: file.type || undefined });
      if (error) {
        setItem(i, { status: "error", message: "A feltöltés nem sikerült." });
        continue;
      }

      setItem(i, { status: "reading" });
      try {
        const result = await processUpload(companyId, path);
        if (result.ok) {
          setItem(i, {
            status: "done",
            message: [result.invoiceNumber ?? "számlaszám nélkül", result.warning].filter(Boolean).join(" – "),
          });
        } else {
          setItem(i, { status: "error", message: result.error });
        }
      } catch {
        setItem(i, { status: "error", message: "A kiolvasás nem sikerült. Próbáld újra." });
      }
    }

    setBusy(false);
    if (inputRef.current) inputRef.current.value = "";
    router.refresh();
  }

  return (
    <form onSubmit={onSubmit} className="fields">
      <label>
        Számlák (PDF vagy fénykép)
        <input
          ref={inputRef}
          type="file"
          multiple
          accept="application/pdf,image/jpeg,image/png,image/webp"
          required
        />
      </label>
      <button className="btn" disabled={busy}>{busy ? "Feldolgozás…" : "Feltöltés és kiolvasás"}</button>

      {items.length > 0 && (
        <ul className="upload-list">
          {items.map((it, i) => (
            <li key={i}>
              <span className="fname">{it.name}</span>
              <span className={`chip ${CHIP[it.status]}`}>{LABEL[it.status]}</span>
              {it.message && <span className="fmsg">{it.message}</span>}
            </li>
          ))}
        </ul>
      )}
    </form>
  );
}
