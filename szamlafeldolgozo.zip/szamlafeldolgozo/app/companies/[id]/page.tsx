import Link from "next/link";
import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import NavSettingsForm from "./nav-settings-form";
import SyncForm from "./sync-form";
import ExportPanel from "./export-panel";
import UploadForm from "./upload-form";
import AccessPanel from "./access-panel";

// A NAV-lekérdezés hosszabb ideig tarthat
export const maxDuration = 60;

const STATUS: Record<string, string> = {
  new: "Új",
  reviewed: "Ellenőrizve",
  exported: "Exportálva",
};

const DIRECTION: Record<string, string> = {
  outgoing: "Kimenő",
  incoming: "Bejövő",
};

function money(amount: number | string | null, currency: string) {
  if (amount === null || amount === undefined) return "–";
  try {
    return new Intl.NumberFormat("hu-HU", {
      style: "currency",
      currency,
      maximumFractionDigits: 0,
    }).format(Number(amount));
  } catch {
    return `${amount} ${currency}`;
  }
}

export default async function CompanyPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const supabase = await createClient();

  // A cég csak akkor jön vissza, ha a felhasználó tagja (Row Level Security)
  const { data: company } = await supabase
    .from("companies")
    .select("id, name, tax_number")
    .eq("id", id)
    .single();

  if (!company) notFound();

  const { data: invoices } = await supabase
    .from("invoices")
    .select("id, invoice_number, issue_date, direction, supplier_name, customer_name, gross_amount, currency, status")
    .eq("company_id", id)
    .order("issue_date", { ascending: false })
    .limit(200);

  // Titkos adatokat nem olvasunk, csak a kapcsolat állapotát
  const admin = createAdminClient();
  const { data: nav } = await admin
    .from("nav_credentials")
    .select("environment, tax_number, last_synced_at")
    .eq("company_id", id)
    .maybeSingle();

  const { data: profiles } = await supabase
    .from("export_profiles")
    .select("id, name, format")
    .eq("company_id", id)
    .order("created_at", { ascending: true });

  const {
    data: { user },
  } = await supabase.auth.getUser();

  const { data: memberRows } = await supabase
    .from("company_members")
    .select("user_id, role, profiles(full_name)")
    .eq("company_id", id);

  const { data: inviteRows } = await supabase
    .from("company_invites")
    .select("id, email")
    .eq("company_id", id)
    .order("created_at", { ascending: true });

  const members = (memberRows ?? []).map((m) => {
    const profile = Array.isArray(m.profiles) ? m.profiles[0] : m.profiles;
    return { user_id: m.user_id as string, role: m.role as string, name: (profile?.full_name ?? null) as string | null };
  });
  const isOwner = members.some((m) => m.user_id === user?.id && m.role === "owner");

  const defaultTax = (nav?.tax_number ?? company.tax_number ?? "").replace(/\D/g, "").slice(0, 8);

  return (
    <div className="stack">
      <div>
        <Link href="/companies" className="back">← Cégek</Link>
        <h1>{company.name}</h1>
        {company.tax_number && <p className="lead tax">{company.tax_number}</p>}
      </div>

      <section className="panel">
        <h2>NAV-kapcsolat</h2>
        {nav ? (
          <>
            <p className="lead">
              Beállítva: {nav.environment === "prod" ? "éles" : "teszt"} környezet, adószám {nav.tax_number}.{" "}
              {nav.last_synced_at
                ? `Utolsó lekérdezés: ${new Date(nav.last_synced_at).toLocaleString("hu-HU", { timeZone: "Europe/Budapest" })}.`
                : "Még nem volt lekérdezés."}
            </p>
            <SyncForm companyId={id} />
            <details>
              <summary>Kapcsolat módosítása</summary>
              <NavSettingsForm
                companyId={id}
                defaultEnvironment={nav.environment === "prod" ? "prod" : "test"}
                defaultTaxNumber={defaultTax}
              />
            </details>
          </>
        ) : (
          <>
            <p className="lead">
              Add meg a NAV Online Számla technikai felhasználójának adatait, hogy a számlák automatikusan megjelenjenek.
            </p>
            <NavSettingsForm companyId={id} defaultEnvironment="test" defaultTaxNumber={defaultTax} />
          </>
        )}
      </section>

      <section className="panel">
        <h2>Papírszámla vagy fénykép feltöltése</h2>
        <p className="lead">
          A NAV-ban nem szereplő számlákat (nyugta, külföldi számla) fotózd le vagy töltsd fel. Az adatokat az AI
          kiolvassa, a listában pedig ellenőrizheted őket. A dokumentum tartalma feldolgozás céljából az AI-szolgáltatóhoz kerül.
        </p>
        <UploadForm companyId={id} />
      </section>

      <section>
        <h2>Számlák</h2>
        {invoices && invoices.length > 0 ? (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Kelt</th>
                  <th>Típus</th>
                  <th>Számlaszám</th>
                  <th>Partner</th>
                  <th className="num">Bruttó</th>
                  <th>Állapot</th>
                </tr>
              </thead>
              <tbody>
                {invoices.map((inv) => (
                  <tr key={inv.id} data-dir={inv.direction}>
                    <td>{inv.issue_date ?? "–"}</td>
                    <td>{DIRECTION[inv.direction] ?? inv.direction}</td>
                    <td>{inv.invoice_number ?? "–"}</td>
                    <td>{(inv.direction === "outgoing" ? inv.customer_name : inv.supplier_name) ?? "–"}</td>
                    <td className="num">{money(inv.gross_amount, inv.currency ?? "HUF")}</td>
                    <td><span className={`chip ${inv.status}`}>{STATUS[inv.status] ?? inv.status}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="panel empty">
            Még nincs számla ezen a cégen. Állítsd be a NAV-kapcsolatot, és kérdezd le a számlákat.
          </div>
        )}
      </section>

      <ExportPanel companyId={id} profiles={profiles ?? []} />

      <AccessPanel companyId={id} isOwner={isOwner} members={members} invites={inviteRows ?? []} />
    </div>
  );
}
