import { deleteExportProfile } from "./actions";
import ProfileForm from "./profile-form";

type Profile = { id: string; name: string; format: string };

export default function ExportPanel({ companyId, profiles }: { companyId: string; profiles: Profile[] }) {
  return (
    <section className="panel">
      <h2>Export a könyvelőprogramba</h2>

      {profiles.length > 0 ? (
        <>
          <form method="get" action={`/api/companies/${companyId}/export`} className="sync">
            <label>
              Exportprofil
              <select name="profile">
                {profiles.map((p) => (
                  <option key={p.id} value={p.id}>{p.name} ({p.format === "xlsx" ? "Excel" : "CSV"})</option>
                ))}
              </select>
            </label>
            <label>
              Mely számlák
              <select name="scope" defaultValue="new">
                <option value="new">Még nem exportáltak</option>
                <option value="all">Mind</option>
              </select>
            </label>
            <label className="check">
              <input type="checkbox" name="mark" value="1" />
              Letöltés után jelöld exportáltnak
            </label>
            <button className="btn">Letöltés</button>
          </form>

          <ul className="profile-list">
            {profiles.map((p) => (
              <li key={p.id}>
                <span>{p.name}</span>
                <form action={deleteExportProfile}>
                  <input type="hidden" name="company_id" value={companyId} />
                  <input type="hidden" name="profile_id" value={p.id} />
                  <button className="btn quiet small">Törlés</button>
                </form>
              </li>
            ))}
          </ul>
        </>
      ) : (
        <p className="lead">Még nincs exportprofil. Hozz létre egyet a könyvelőprogram elvárásai szerint.</p>
      )}

      <details>
        <summary>Új exportprofil</summary>
        <ProfileForm companyId={companyId} />
      </details>
    </section>
  );
}
