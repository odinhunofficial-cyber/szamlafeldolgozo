"use client";

import { useActionState } from "react";
import { syncInvoices } from "./actions";
import type { FormState } from "@/lib/state";

export default function SyncForm({ companyId }: { companyId: string }) {
  const [state, action, pending] = useActionState<FormState, FormData>(syncInvoices, {});

  return (
    <form action={action} className="sync">
      <input type="hidden" name="company_id" value={companyId} />
      <label>
        Időszak
        <select name="days" defaultValue="30">
          <option value="30">Utolsó 30 nap</option>
          <option value="90">Utolsó 90 nap</option>
        </select>
      </label>
      <button className="btn" disabled={pending}>
        {pending ? "Lekérdezés folyamatban…" : "Számlák lekérdezése a NAV-ból"}
      </button>
      {state.error && <p className="notice error" role="alert">{state.error}</p>}
      {state.info && <p className="notice info" role="status">{state.info}</p>}
    </form>
  );
}
