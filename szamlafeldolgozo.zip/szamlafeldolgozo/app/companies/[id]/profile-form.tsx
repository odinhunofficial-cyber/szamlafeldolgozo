"use client";

import { useActionState, useState } from "react";
import { createExportProfile } from "./actions";
import { FIELDS } from "@/lib/export/fields";
import type { FormState } from "@/lib/state";

type Col = { header: string; field: string };

const DEFAULT_COLUMNS: Col[] = [
  { header: "Számlaszám", field: "invoice_number" },
  { header: "Kelt", field: "issue_date" },
  { header: "Irány", field: "direction" },
  { header: "Partner", field: "partner_name" },
  { header: "Partner adószám", field: "partner_tax_number" },
  { header: "Nettó", field: "net_amount" },
  { header: "Áfa", field: "vat_amount" },
  { header: "Bruttó", field: "gross_amount" },
  { header: "Pénznem", field: "currency" },
];

export default function ProfileForm({ companyId }: { companyId: string }) {
  const [state, action, pending] = useActionState<FormState, FormData>(createExportProfile, {});
  const [cols, setCols] = useState<Col[]>(DEFAULT_COLUMNS);

  const update = (i: number, patch: Partial<Col>) =>
    setCols((prev) => prev.map((c, idx) => (idx === i ? { ...c, ...patch } : c)));

  const move = (i: number, delta: number) =>
    setCols((prev) => {
      const j = i + delta;
      if (j < 0 || j >= prev.length) return prev;
      const next = [...prev];
      [next[i], next[j]] = [next[j], next[i]];
      return next;
    });

  const remove = (i: number) => setCols((prev) => prev.filter((_, idx) => idx !== i));
  const add = () => setCols((prev) => [...prev, { header: "", field: "invoice_number" }]);

  return (
    <form action={action} className="fields">
      <input type="hidden" name="company_id" value={companyId} />
      <input type="hidden" name="mapping" value={JSON.stringify(cols)} />

      <label>
        Profil neve
        <input name="name" type="text" placeholder="pl. Kulcs-Soft import" required />
      </label>
      <label>
        Fájltípus
        <select name="format" defaultValue="csv">
          <option value="csv">CSV</option>
          <option value="xlsx">Excel (xlsx)</option>
        </select>
      </label>
      <label>
        Elválasztójel (CSV)
        <select name="delimiter" defaultValue=";">
          <option value=";">Pontosvessző ( ; )</option>
          <option value=",">Vessző ( , )</option>
          <option value="tab">Tabulátor</option>
        </select>
      </label>
      <label>
        Tizedesjel
        <select name="decimal_separator" defaultValue=",">
          <option value=",">Vessző ( 1234,50 )</option>
          <option value=".">Pont ( 1234.50 )</option>
        </select>
      </label>
      <label>
        Dátumformátum
        <select name="date_format" defaultValue="YYYY-MM-DD">
          <option value="YYYY-MM-DD">2026-09-30</option>
          <option value="YYYY.MM.DD">2026.09.30</option>
          <option value="DD.MM.YYYY">30.09.2026</option>
          <option value="YYYYMMDD">20260930</option>
        </select>
      </label>
      <label>
        Karakterkódolás (CSV)
        <select name="encoding" defaultValue="utf-8">
          <option value="utf-8">UTF-8</option>
          <option value="windows-1250">Windows-1250</option>
        </select>
      </label>

      <div className="cols">
        <strong>Oszlopok (a megadott sorrendben kerülnek a fájlba)</strong>
        {cols.map((c, i) => (
          <div className="colrow" key={i}>
            <input
              value={c.header}
              onChange={(e) => update(i, { header: e.target.value })}
              aria-label={`${i + 1}. oszlop fejléce`}
              placeholder="Fejléc"
            />
            <select
              value={c.field}
              onChange={(e) => update(i, { field: e.target.value })}
              aria-label={`${i + 1}. oszlop mezője`}
            >
              {FIELDS.map((f) => (
                <option key={f.key} value={f.key}>{f.label}</option>
              ))}
            </select>
            <div className="colbtns">
              <button type="button" className="btn quiet small" onClick={() => move(i, -1)} disabled={i === 0} aria-label="Feljebb">↑</button>
              <button type="button" className="btn quiet small" onClick={() => move(i, 1)} disabled={i === cols.length - 1} aria-label="Lejjebb">↓</button>
              <button type="button" className="btn quiet small" onClick={() => remove(i)} aria-label="Oszlop törlése">Törlés</button>
            </div>
          </div>
        ))}
        <button type="button" className="btn quiet small" onClick={add}>Oszlop hozzáadása</button>
      </div>

      {state.error && <p className="notice error" role="alert">{state.error}</p>}
      {state.info && <p className="notice info" role="status">{state.info}</p>}
      <button className="btn" disabled={pending}>{pending ? "Mentés…" : "Profil mentése"}</button>
    </form>
  );
}
