"use client";

import { useActionState } from "react";
import { saveNavCredentials } from "./actions";
import type { FormState } from "@/lib/state";

export default function NavSettingsForm({
  companyId,
  defaultEnvironment,
  defaultTaxNumber,
}: {
  companyId: string;
  defaultEnvironment: "test" | "prod";
  defaultTaxNumber: string;
}) {
  const [state, action, pending] = useActionState<FormState, FormData>(saveNavCredentials, {});

  return (
    <form action={action} className="fields">
      <input type="hidden" name="company_id" value={companyId} />
      <label>
        Környezet
        <select name="environment" defaultValue={defaultEnvironment}>
          <option value="test">Teszt (onlineszamla-test.nav.gov.hu)</option>
          <option value="prod">Éles (onlineszamla.nav.gov.hu)</option>
        </select>
      </label>
      <label>
        Adószám (első 8 számjegy)
        <input name="tax_number" type="text" inputMode="numeric" defaultValue={defaultTaxNumber} required />
      </label>
      <label>
        Technikai felhasználó neve
        <input name="login" type="text" autoComplete="off" required />
      </label>
      <label>
        Technikai felhasználó jelszava
        <input name="password" type="password" autoComplete="new-password" required />
      </label>
      <label>
        Aláírókulcs
        <input name="signature_key" type="password" autoComplete="off" required />
      </label>
      <label>
        Cserekulcs (számlalekérdezéshez nem kell)
        <input name="exchange_key" type="password" autoComplete="off" />
      </label>
      {state.error && <p className="notice error" role="alert">{state.error}</p>}
      {state.info && <p className="notice info" role="status">{state.info}</p>}
      <button className="btn" disabled={pending}>{pending ? "Mentés…" : "NAV-adatok mentése"}</button>
    </form>
  );
}
