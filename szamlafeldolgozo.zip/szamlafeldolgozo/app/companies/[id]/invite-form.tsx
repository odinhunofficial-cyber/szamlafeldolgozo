"use client";

import { useActionState } from "react";
import { inviteAccountant } from "./access-actions";
import type { FormState } from "@/lib/state";

export default function InviteForm({ companyId }: { companyId: string }) {
  const [state, action, pending] = useActionState<FormState, FormData>(inviteAccountant, {});

  return (
    <form action={action} className="fields">
      <input type="hidden" name="company_id" value={companyId} />
      <label>
        A könyvelő e-mail-címe
        <input name="email" type="email" autoComplete="off" required />
      </label>
      <p className="lead">
        A könyvelő ezzel az e-mail-címmel regisztráljon (vagy jelentkezzen be) az alkalmazásban, és a cég
        automatikusan megjelenik nála. Küldd el neki az alkalmazás címét.
      </p>
      {state.error && <p className="notice error" role="alert">{state.error}</p>}
      {state.info && <p className="notice info" role="status">{state.info}</p>}
      <button className="btn" disabled={pending}>{pending ? "Mentés…" : "Meghívás"}</button>
    </form>
  );
}
