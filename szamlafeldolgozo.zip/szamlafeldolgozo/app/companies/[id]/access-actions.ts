"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { isCompanyOwner } from "@/lib/auth";
import type { FormState } from "@/lib/state";

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export async function inviteAccountant(_prev: FormState, formData: FormData): Promise<FormState> {
  const companyId = String(formData.get("company_id") ?? "");
  const email = String(formData.get("email") ?? "").trim().toLowerCase();

  if (!(await isCompanyOwner(companyId))) return { error: "Csak a cég tulajdonosa hívhat meg másokat." };
  if (!EMAIL.test(email) || email.length > 200) return { error: "Adj meg egy érvényes e-mail-címet." };

  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (user?.email?.toLowerCase() === email) return { error: "Magadat nem kell meghívnod." };

  const { error } = await supabase
    .from("company_invites")
    .insert({ company_id: companyId, email, role: "accountant", invited_by: user?.id });

  if (error) {
    if (error.code === "23505") return { error: "Ezt a címet már meghívtad." };
    console.error("Meghívó mentési hiba", error);
    return { error: "A meghívó mentése nem sikerült." };
  }

  revalidatePath(`/companies/${companyId}`);
  return {
    info: `Meghívó elmentve. ${email} akkor kap hozzáférést, amikor ezzel az e-mail-címmel regisztrál vagy bejelentkezik az alkalmazásban.`,
  };
}

export async function revokeInvite(formData: FormData): Promise<void> {
  const companyId = String(formData.get("company_id") ?? "");
  const inviteId = String(formData.get("invite_id") ?? "");
  if (!(await isCompanyOwner(companyId))) return;

  const supabase = await createClient();
  await supabase.from("company_invites").delete().eq("id", inviteId).eq("company_id", companyId);
  revalidatePath(`/companies/${companyId}`);
}

export async function removeMember(formData: FormData): Promise<void> {
  const companyId = String(formData.get("company_id") ?? "");
  const userId = String(formData.get("user_id") ?? "");
  if (!(await isCompanyOwner(companyId))) return;

  const supabase = await createClient();
  await supabase
    .from("company_members")
    .delete()
    .eq("company_id", companyId)
    .eq("user_id", userId)
    .eq("role", "accountant");
  revalidatePath(`/companies/${companyId}`);
}
