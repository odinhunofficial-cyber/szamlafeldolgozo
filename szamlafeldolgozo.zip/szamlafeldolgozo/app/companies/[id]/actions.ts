"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { encrypt } from "@/lib/crypto";
import { hashPassword, NavError } from "@/lib/nav/client";
import { syncCompanyInvoices } from "@/lib/nav/sync";
import { FIELDS } from "@/lib/export/fields";
import type { FormState } from "@/lib/state";

async function isMember(companyId: string): Promise<boolean> {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return false;

  const { data } = await supabase
    .from("company_members")
    .select("company_id")
    .eq("company_id", companyId)
    .eq("user_id", user.id)
    .maybeSingle();

  return !!data;
}

export async function saveNavCredentials(_prev: FormState, formData: FormData): Promise<FormState> {
  const companyId = String(formData.get("company_id") ?? "");
  const login = String(formData.get("login") ?? "").trim();
  const password = String(formData.get("password") ?? "");
  const signatureKey = String(formData.get("signature_key") ?? "").trim();
  const exchangeKey = String(formData.get("exchange_key") ?? "").trim();
  const taxNumber = String(formData.get("tax_number") ?? "").replace(/\D/g, "").slice(0, 8);
  const environment = formData.get("environment") === "prod" ? "prod" : "test";

  if (!(await isMember(companyId))) return { error: "Nincs jogosultságod ehhez a céghez." };
  if (taxNumber.length !== 8) return { error: "Az adószám első 8 számjegyét add meg." };
  if (!login || !password || !signatureKey) {
    return { error: "A felhasználónevet, a jelszót és az aláírókulcsot is meg kell adni." };
  }

  try {
    const admin = createAdminClient();
    const { error } = await admin.from("nav_credentials").upsert({
      company_id: companyId,
      environment,
      tax_number: taxNumber,
      login_enc: encrypt(login),
      // A NAV a jelszó SHA-512 lenyomatát kéri, ezért csak azt mentjük (titkosítva).
      password_enc: encrypt(hashPassword(password)),
      signature_key_enc: encrypt(signatureKey),
      exchange_key_enc: exchangeKey ? encrypt(exchangeKey) : null,
      updated_at: new Date().toISOString(),
    });
    if (error) throw error;
  } catch (e) {
    console.error("NAV-adatok mentési hiba", e);
    return { error: "A NAV-adatok mentése nem sikerült. Ellenőrizd a szerver beállításait." };
  }

  revalidatePath(`/companies/${companyId}`);
  return { info: "A NAV-kapcsolat adatai elmentve." };
}

export async function syncInvoices(_prev: FormState, formData: FormData): Promise<FormState> {
  const companyId = String(formData.get("company_id") ?? "");
  const days = Number(formData.get("days")) === 90 ? 90 : 30;

  if (!(await isMember(companyId))) return { error: "Nincs jogosultságod ehhez a céghez." };

  try {
    const result = await syncCompanyInvoices(companyId, days);
    revalidatePath(`/companies/${companyId}`);
    return { info: `Lekérdezve: ${result.fetched} számla, ebből új: ${result.inserted}.` };
  } catch (e) {
    if (e instanceof NavError) return { error: e.message };
    console.error("Számlalekérdezési hiba", e);
    return { error: "A lekérdezés nem sikerült. Próbáld újra később." };
  }
}

const DATE_FORMATS = ["YYYY-MM-DD", "YYYY.MM.DD", "DD.MM.YYYY", "YYYYMMDD"];

export async function createExportProfile(_prev: FormState, formData: FormData): Promise<FormState> {
  const companyId = String(formData.get("company_id") ?? "");
  if (!(await isMember(companyId))) return { error: "Nincs jogosultságod ehhez a céghez." };

  const name = String(formData.get("name") ?? "").trim().slice(0, 80);
  if (!name) return { error: "Adj nevet a profilnak, például a könyvelőprogram nevét." };

  const format = formData.get("format") === "xlsx" ? "xlsx" : "csv";
  const delimiterRaw = String(formData.get("delimiter") ?? ";");
  const delimiter = delimiterRaw === "tab" ? "\t" : delimiterRaw === "," ? "," : ";";
  const decimal = formData.get("decimal_separator") === "." ? "." : ",";
  const dateRaw = String(formData.get("date_format") ?? "");
  const dateFormat = DATE_FORMATS.includes(dateRaw) ? dateRaw : "YYYY-MM-DD";
  const encoding = formData.get("encoding") === "windows-1250" ? "windows-1250" : "utf-8";

  let parsed: unknown;
  try {
    parsed = JSON.parse(String(formData.get("mapping") ?? "[]"));
  } catch {
    return { error: "Az oszlopok beállítása hibás." };
  }
  if (!Array.isArray(parsed) || parsed.length === 0 || parsed.length > 40) {
    return { error: "Legalább egy oszlop kell (legfeljebb 40)." };
  }

  const validFields = new Set<string>(FIELDS.map((f) => f.key));
  const mapping: { header: string; field: string }[] = [];
  for (const c of parsed) {
    const header = typeof c?.header === "string" ? c.header.trim().slice(0, 80) : "";
    const field = typeof c?.field === "string" ? c.field : "";
    if (!header || !validFields.has(field)) return { error: "Minden oszlophoz kell fejléc és mező." };
    mapping.push({ header, field });
  }

  const supabase = await createClient();
  const { error } = await supabase.from("export_profiles").insert({
    company_id: companyId,
    name,
    format,
    delimiter,
    decimal_separator: decimal,
    date_format: dateFormat,
    encoding,
    column_mapping: mapping,
  });
  if (error) {
    console.error("Exportprofil mentési hiba", error);
    return { error: "A profil mentése nem sikerült." };
  }

  revalidatePath(`/companies/${companyId}`);
  return { info: "Az exportprofil elmentve." };
}

export async function deleteExportProfile(formData: FormData): Promise<void> {
  const companyId = String(formData.get("company_id") ?? "");
  const profileId = String(formData.get("profile_id") ?? "");
  if (!(await isMember(companyId))) return;

  const supabase = await createClient();
  await supabase.from("export_profiles").delete().eq("id", profileId).eq("company_id", companyId);
  revalidatePath(`/companies/${companyId}`);
}
