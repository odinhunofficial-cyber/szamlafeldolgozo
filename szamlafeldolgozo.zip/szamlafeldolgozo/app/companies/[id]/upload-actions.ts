"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { isCompanyMember } from "@/lib/auth";
import { AiError, extractInvoice } from "@/lib/ai/extract";
import { digits8, reviewWarning } from "@/lib/ai/normalize";
import type { UploadResult } from "@/lib/state";

const MEDIA: Record<string, string> = {
  pdf: "application/pdf",
  jpg: "image/jpeg",
  jpeg: "image/jpeg",
  png: "image/png",
  webp: "image/webp",
};

const MAX_BYTES = 10 * 1024 * 1024;

export async function processUpload(companyId: string, path: string): Promise<UploadResult> {
  if (!(await isCompanyMember(companyId))) return { ok: false, error: "Nincs jogosultságod ehhez a céghez." };
  if (!path.startsWith(`${companyId}/`) || path.includes("..")) return { ok: false, error: "Érvénytelen fájl." };

  const ext = path.split(".").pop()?.toLowerCase() ?? "";
  const mediaType = MEDIA[ext];
  if (!mediaType) return { ok: false, error: "Csak PDF, JPG, PNG és WEBP tölthető fel." };

  const supabase = await createClient();

  const { data: blob, error: downloadError } = await supabase.storage.from("invoice-files").download(path);
  if (downloadError || !blob) return { ok: false, error: "A feltöltött fájl nem olvasható." };
  if (blob.size > MAX_BYTES) return { ok: false, error: "A fájl túl nagy (legfeljebb 10 MB)." };

  const { data: company } = await supabase.from("companies").select("tax_number").eq("id", companyId).single();

  let extracted;
  try {
    extracted = await extractInvoice(Buffer.from(await blob.arrayBuffer()).toString("base64"), mediaType);
  } catch (e) {
    if (e instanceof AiError) return { ok: false, error: e.message };
    console.error("Kiolvasási hiba", e);
    return { ok: false, error: "A kiolvasás nem sikerült. Próbáld újra." };
  }

  // Irány: ha a cég adószáma a kiállítóé, kimenő; egyébként bejövő
  const own = digits8(company?.tax_number ?? null);
  const direction = own && digits8(extracted.supplier_tax_number) === own ? "outgoing" : "incoming";
  const warning = reviewWarning(extracted);

  const { error: insertError } = await supabase.from("invoices").insert({
    company_id: companyId,
    source: "upload",
    direction,
    invoice_number: extracted.invoice_number,
    issue_date: extracted.issue_date,
    supplier_name: extracted.supplier_name,
    supplier_tax_number: extracted.supplier_tax_number,
    customer_name: extracted.customer_name,
    customer_tax_number: extracted.customer_tax_number,
    net_amount: extracted.net_amount,
    vat_amount: extracted.vat_amount,
    gross_amount: extracted.gross_amount,
    currency: extracted.currency,
    file_path: path,
    raw: { ...extracted, review_warning: warning },
  });

  if (insertError) {
    if (insertError.code === "23505") return { ok: false, error: "Ez a számla már szerepel a listában." };
    console.error("Számla mentési hiba", insertError);
    return { ok: false, error: "A számla mentése nem sikerült." };
  }

  revalidatePath(`/companies/${companyId}`);
  return { ok: true, invoiceNumber: extracted.invoice_number, warning: warning ?? undefined };
}
