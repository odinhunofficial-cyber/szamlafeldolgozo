"use client";

import { useActionState } from "react";
import { createCompany } from "./actions";
import type { FormState } from "@/lib/state";

export default function CreateCompanyForm() {
  const [state, action, pending] = useActionState<FormState, FormData>(createCompany, {});

  return (
    <form action={action} className="fields">
      <label>
        Cégnév
        <input name="name" type="text" required />
      </label>
      <label>
        Adószám
        <input name="tax_number" type="text" inputMode="numeric" placeholder="12345678-1-42" />
      </label>
      {state.error && <p className="notice error" role="alert">{state.error}</p>}
      <button className="btn" disabled={pending}>Cég felvétele</button>
    </form>
  );
}
