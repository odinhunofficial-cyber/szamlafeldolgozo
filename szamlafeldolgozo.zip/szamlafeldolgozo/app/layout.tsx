import type { Metadata } from "next";
import type { ReactNode } from "react";
import { IBM_Plex_Sans } from "next/font/google";
import "./globals.css";

const body = IBM_Plex_Sans({
  subsets: ["latin", "latin-ext"],
  weight: ["400", "500", "600"],
  variable: "--font-body",
  display: "swap",
});

export const metadata: Metadata = {
  title: "Számlafeldolgozó",
  description: "Számlák egy helyen a vállalkozónak és a könyvelőnek.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="hu" className={body.variable}>
      <body>{children}</body>
    </html>
  );
}
