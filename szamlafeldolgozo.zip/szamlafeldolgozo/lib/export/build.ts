import iconv from "iconv-lite";
import ExcelJS from "exceljs";
import { buildCsvText, formatDate, type ExportProfile } from "./csv";
import { FIELD_KIND, rawValue, type InvoiceRow } from "./fields";

export function buildCsv(rows: InvoiceRow[], p: ExportProfile): Uint8Array {
  const text = buildCsvText(rows, p);
  if (p.encoding === "windows-1250") {
    return new Uint8Array(iconv.encode(text, "windows-1250"));
  }
  // UTF-8 BOM, hogy az Excel is helyesen olvassa az ékezeteket
  return new Uint8Array(Buffer.from("\uFEFF" + text, "utf-8"));
}

export async function buildXlsx(rows: InvoiceRow[], p: ExportProfile): Promise<Uint8Array> {
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet("Számlák");

  ws.addRow(p.column_mapping.map((c) => c.header));
  ws.getRow(1).font = { bold: true };

  for (const row of rows) {
    ws.addRow(
      p.column_mapping.map((c) => {
        const v = rawValue(row, c.field);
        if (v === null || v === undefined) return null;
        const kind = FIELD_KIND[c.field];
        if (kind === "amount") {
          const n = Number(v);
          return Number.isFinite(n) ? n : null;
        }
        if (kind === "date") return formatDate(String(v), p.date_format);
        return String(v);
      })
    );
  }

  ws.columns.forEach((col) => {
    col.width = 18;
  });

  return new Uint8Array(await wb.xlsx.writeBuffer());
}
