import { FIELD_KIND, rawValue, type FieldKey, type InvoiceRow } from "./fields";

export type ExportProfile = {
  format: "csv" | "xlsx";
  delimiter: string;
  decimal_separator: string;
  date_format: string;
  encoding: "utf-8" | "windows-1250";
  column_mapping: { header: string; field: FieldKey }[];
};

export function formatDate(value: string, fmt: string): string {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(value);
  if (!m) return value;
  return fmt.replace("YYYY", m[1]).replace("MM", m[2]).replace("DD", m[3]);
}

export function formatAmount(value: number | string | null, decimal: string): string {
  if (value === null || value === undefined || value === "") return "";
  const n = Number(value);
  if (!Number.isFinite(n)) return "";
  return n.toFixed(2).replace(".", decimal);
}

// CSV-képletinjekció elleni védelem: a NAV-ból érkező szövegek (pl. partnernév) nem indulhatnak képletjellel
export function safeText(s: string): string {
  return /^[=+\-@\t\r]/.test(s) ? `'${s}` : s;
}

export function cellText(row: InvoiceRow, field: FieldKey, p: ExportProfile): string {
  const v = rawValue(row, field);
  if (v === null || v === undefined) return "";
  switch (FIELD_KIND[field]) {
    case "amount":
      return formatAmount(v, p.decimal_separator);
    case "date":
      return formatDate(String(v), p.date_format);
    default:
      return safeText(String(v));
  }
}

function escapeCsv(s: string, delimiter: string): string {
  return s.includes(delimiter) || /["\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

export function buildCsvText(rows: InvoiceRow[], p: ExportProfile): string {
  const lines = [p.column_mapping.map((c) => escapeCsv(c.header, p.delimiter)).join(p.delimiter)];
  for (const row of rows) {
    lines.push(
      p.column_mapping.map((c) => escapeCsv(cellText(row, c.field, p), p.delimiter)).join(p.delimiter)
    );
  }
  return lines.join("\r\n") + "\r\n";
}
