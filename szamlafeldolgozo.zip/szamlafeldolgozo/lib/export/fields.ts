// Tiszta (szerver- és böngészőoldalon is használható) mezőleírások az exporthoz.

export type InvoiceRow = {
  invoice_number: string | null;
  issue_date: string | null;
  direction: string;
  status: string;
  supplier_name: string | null;
  supplier_tax_number: string | null;
  customer_name: string | null;
  customer_tax_number: string | null;
  net_amount: number | string | null;
  vat_amount: number | string | null;
  gross_amount: number | string | null;
  currency: string | null;
  category: string | null;
};

export type FieldKind = "text" | "date" | "amount";

export const FIELDS = [
  { key: "invoice_number", label: "Számlaszám", kind: "text" },
  { key: "issue_date", label: "Kelt", kind: "date" },
  { key: "direction", label: "Irány (Kimenő/Bejövő)", kind: "text" },
  { key: "partner_name", label: "Partner neve", kind: "text" },
  { key: "partner_tax_number", label: "Partner adószáma", kind: "text" },
  { key: "supplier_name", label: "Szállító neve", kind: "text" },
  { key: "supplier_tax_number", label: "Szállító adószáma", kind: "text" },
  { key: "customer_name", label: "Vevő neve", kind: "text" },
  { key: "customer_tax_number", label: "Vevő adószáma", kind: "text" },
  { key: "net_amount", label: "Nettó összeg", kind: "amount" },
  { key: "vat_amount", label: "Áfa összeg", kind: "amount" },
  { key: "gross_amount", label: "Bruttó összeg", kind: "amount" },
  { key: "currency", label: "Pénznem", kind: "text" },
  { key: "category", label: "Kategória", kind: "text" },
  { key: "status", label: "Állapot", kind: "text" },
] as const;

export type FieldKey = (typeof FIELDS)[number]["key"];

export const FIELD_KIND: Record<string, FieldKind> = Object.fromEntries(
  FIELDS.map((f) => [f.key, f.kind])
);

const DIRECTION: Record<string, string> = { outgoing: "Kimenő", incoming: "Bejövő" };
const STATUS: Record<string, string> = { new: "Új", reviewed: "Ellenőrizve", exported: "Exportálva" };

export function rawValue(row: InvoiceRow, key: FieldKey): string | number | null {
  switch (key) {
    case "direction":
      return DIRECTION[row.direction] ?? row.direction;
    case "status":
      return STATUS[row.status] ?? row.status;
    case "partner_name":
      return row.direction === "outgoing" ? row.customer_name : row.supplier_name;
    case "partner_tax_number":
      return row.direction === "outgoing" ? row.customer_tax_number : row.supplier_tax_number;
    default:
      return row[key] ?? null;
  }
}
