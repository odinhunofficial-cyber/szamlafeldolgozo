export type Extracted = {
  invoice_number: string | null;
  issue_date: string | null;
  supplier_name: string | null;
  supplier_tax_number: string | null;
  customer_name: string | null;
  customer_tax_number: string | null;
  net_amount: number | null;
  vat_amount: number | null;
  gross_amount: number | null;
  currency: string;
  document_type: string;
  confidence: "high" | "medium" | "low";
  notes: string | null;
};

function str(v: unknown): string | null {
  return typeof v === "string" && v.trim() ? v.trim().slice(0, 200) : null;
}

function num(v: unknown): number | null {
  if (typeof v === "number") return Number.isFinite(v) ? v : null;
  if (typeof v !== "string" || !v.trim()) return null;
  let s = v.replace(/\s/g, "");
  if (s.includes(".") && s.includes(",")) s = s.replace(/\./g, "");
  const n = Number(s.replace(",", "."));
  return Number.isFinite(n) ? n : null;
}

// A modell válaszából kiszedi az első JSON-objektumot (kódblokk vagy magyarázat esetén is)
export function parseModelJson(text: string): unknown {
  const start = text.indexOf("{");
  const end = text.lastIndexOf("}");
  if (start === -1 || end <= start) throw new Error("A válasz nem tartalmaz JSON-t.");
  return JSON.parse(text.slice(start, end + 1));
}

export function normalize(raw: unknown): Extracted {
  const o = (raw && typeof raw === "object" ? raw : {}) as Record<string, unknown>;

  const date = str(o.issue_date);
  const currency = str(o.currency)?.toUpperCase();
  const confidence = o.confidence === "high" || o.confidence === "low" ? o.confidence : "medium";

  let net = num(o.net_amount);
  let vat = num(o.vat_amount);
  let gross = num(o.gross_amount);
  if (gross === null && net !== null && vat !== null) gross = Math.round((net + vat) * 100) / 100;
  if (vat === null && net !== null && gross !== null) vat = Math.round((gross - net) * 100) / 100;
  if (net === null && vat !== null && gross !== null) net = Math.round((gross - vat) * 100) / 100;

  return {
    invoice_number: str(o.invoice_number),
    issue_date: date && /^\d{4}-\d{2}-\d{2}$/.test(date) ? date : null,
    supplier_name: str(o.supplier_name),
    supplier_tax_number: str(o.supplier_tax_number),
    customer_name: str(o.customer_name),
    customer_tax_number: str(o.customer_tax_number),
    net_amount: net,
    vat_amount: vat,
    gross_amount: gross,
    currency: currency && /^[A-Z]{3}$/.test(currency) ? currency : "HUF",
    document_type: str(o.document_type) ?? "invoice",
    confidence,
    notes: str(o.notes),
  };
}

// Az adószám első 8 számjegye (pl. 12345678-2-42 -> 12345678)
export function digits8(v: string | null): string | null {
  if (!v) return null;
  const d = v.replace(/\D/g, "");
  return d.length >= 8 ? d.slice(0, 8) : null;
}

// Emberi ellenőrzést kérő figyelmeztetés, ha valami gyanús
export function reviewWarning(e: Extracted): string | null {
  if (e.document_type !== "invoice" && e.document_type !== "receipt") return "Nem számlának tűnik, ellenőrizd.";
  if (e.confidence === "low") return "Bizonytalan kiolvasás, ellenőrizd.";
  if (e.net_amount !== null && e.vat_amount !== null && e.gross_amount !== null) {
    if (Math.abs(e.net_amount + e.vat_amount - e.gross_amount) > 1) return "Az összegek nem egyeznek, ellenőrizd.";
  }
  if (e.gross_amount === null) return "Nem sikerült kiolvasni az összeget, ellenőrizd.";
  return null;
}
