import { createClient } from "@/lib/supabase/server";

// Igaz, ha a bejelentkezett felhasználó tagja a cégnek
export async function isCompanyMember(companyId: string): Promise<boolean> {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return false;

  const { data } = await supabase
    .from("company_members")
    .select("company_id")
    .eq("company_id", companyId)
    .eq("user_id", user.id)
    .maybeSingle();

  return !!data;
}

// Igaz, ha a bejelentkezett felhasználó a cég tulajdonosa
export async function isCompanyOwner(companyId: string): Promise<boolean> {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return false;

  const { data } = await supabase
    .from("company_members")
    .select("company_id")
    .eq("company_id", companyId)
    .eq("user_id", user.id)
    .eq("role", "owner")
    .maybeSingle();

  return !!data;
}
