import { createHash, randomBytes } from "node:crypto";
import { XMLParser } from "fast-xml-parser";

export type NavEnvironment = "test" | "prod";
export type NavDirection = "INBOUND" | "OUTBOUND";

export type NavCredentials = {
  login: string;
  passwordHash: string; // SHA-512, nagybetűs hex
  signatureKey: string;
  taxNumber: string; // az adószám első 8 számjegye
  environment: NavEnvironment;
};

export type InvoiceDigest = Record<string, string | undefined>;

// Várt, felhasználónak megjeleníthető hiba
export class NavError extends Error {}

const BASE_URL: Record<NavEnvironment, string> = {
  test: "https://api-test.onlineszamla.nav.gov.hu/invoiceService/v3",
  prod: "https://api.onlineszamla.nav.gov.hu/invoiceService/v3",
};

const parser = new XMLParser({
  removeNSPrefix: true,
  ignoreAttributes: true,
  parseTagValue: false, // az adószámok és számlaszámok maradjanak szövegek
  isArray: (name) => name === "invoiceDigest",
});

export function hashPassword(password: string): string {
  return createHash("sha512").update(password, "utf8").digest("hex").toUpperCase();
}

function esc(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

// requestSignature = SHA3-512(requestId + időbélyeg (yyyyMMddHHmmss, UTC) + aláírókulcs)
function sign(requestId: string, compactTimestamp: string, signatureKey: string): string {
  return createHash("sha3-512")
    .update(requestId + compactTimestamp + signatureKey, "utf8")
    .digest("hex")
    .toUpperCase();
}

function softwareXml(): string {
  // A softwareId pontosan 18 karakter ([0-9A-Z-]), és szoftverenként egyedi legyen.
  const id = process.env.NAV_SOFTWARE_ID ?? "SZAMLAFELD-MVP-001";
  const devName = process.env.NAV_DEV_NAME ?? "Fejleszto";
  const devContact = process.env.NAV_DEV_CONTACT ?? "info@example.com";

  return `<software>
    <softwareId>${esc(id)}</softwareId>
    <softwareName>Szamlafeldolgozo</softwareName>
    <softwareOperation>ONLINE_SERVICE</softwareOperation>
    <softwareMainVersion>0.1</softwareMainVersion>
    <softwareDevName>${esc(devName)}</softwareDevName>
    <softwareDevContact>${esc(devContact)}</softwareDevContact>
    <softwareDevCountryCode>HU</softwareDevCountryCode>
  </software>`;
}

function envelope(rootName: string, creds: NavCredentials, bodyXml: string): string {
  const requestId = "R" + randomBytes(12).toString("hex"); // 25 karakter
  const iso = new Date().toISOString();
  const compact = iso.replace(/[-:TZ]/g, "").slice(0, 14);

  return `<?xml version="1.0" encoding="UTF-8"?>
<${rootName} xmlns="http://schemas.nav.gov.hu/OSA/3.0/api" xmlns:common="http://schemas.nav.gov.hu/NTCA/1.0/common">
  <common:header>
    <common:requestId>${requestId}</common:requestId>
    <common:timestamp>${iso}</common:timestamp>
    <common:requestVersion>3.0</common:requestVersion>
    <common:headerVersion>1.0</common:headerVersion>
  </common:header>
  <common:user>
    <common:login>${esc(creds.login)}</common:login>
    <common:passwordHash cryptoType="SHA-512">${creds.passwordHash}</common:passwordHash>
    <common:taxNumber>${esc(creds.taxNumber)}</common:taxNumber>
    <common:requestSignature cryptoType="SHA3-512">${sign(requestId, compact, creds.signatureKey)}</common:requestSignature>
  </common:user>
  ${softwareXml()}
  ${bodyXml}
</${rootName}>`;
}

const FRIENDLY_ERRORS: Record<string, string> = {
  INVALID_SECURITY_USER: "A NAV szerint hibás a technikai felhasználó neve vagy jelszava.",
  INVALID_REQUEST_SIGNATURE: "A NAV szerint hibás az aláírókulcs.",
};

function generalError(general: { result?: { errorCode?: string; message?: string } }): NavError {
  const code = general.result?.errorCode ?? "";
  const message = general.result?.message ?? "";
  return new NavError(FRIENDLY_ERRORS[code] ?? `A NAV hibát jelzett${code ? ` (${code})` : ""}: ${message}`);
}

// Egy oldal számlaösszesítő lekérdezése (egy időablak, max. 35 nap a NAV szabálya szerint)
export async function queryInvoiceDigestPage(
  creds: NavCredentials,
  direction: NavDirection,
  dateFrom: string,
  dateTo: string,
  page: number
): Promise<{ availablePage: number; digests: InvoiceDigest[] }> {
  const body = `<page>${page}</page>
  <invoiceDirection>${direction}</invoiceDirection>
  <invoiceQueryParams>
    <mandatoryQueryParams>
      <invoiceIssueDate>
        <dateFrom>${dateFrom}</dateFrom>
        <dateTo>${dateTo}</dateTo>
      </invoiceIssueDate>
    </mandatoryQueryParams>
  </invoiceQueryParams>`;

  let res: Response;
  try {
    res = await fetch(`${BASE_URL[creds.environment]}/queryInvoiceDigest`, {
      method: "POST",
      headers: { "Content-Type": "application/xml", Accept: "application/xml" },
      body: envelope("QueryInvoiceDigestRequest", creds, body),
      cache: "no-store",
      signal: AbortSignal.timeout(20000),
    });
  } catch {
    throw new NavError("A NAV szervere nem érhető el vagy lassan válaszol. Próbáld újra később.");
  }

  const text = await res.text();
  const parsed = parser.parse(text);

  if (parsed.GeneralErrorResponse) throw generalError(parsed.GeneralErrorResponse);
  if (!res.ok) throw new NavError(`A NAV nem érhető el (HTTP ${res.status}).`);

  const root = parsed.QueryInvoiceDigestResponse;
  if (!root) throw new NavError("A NAV váratlan választ adott.");
  if (root.result?.funcCode !== "OK") throw new NavError("A NAV nem tudta teljesíteni a lekérdezést.");

  const result = root.invoiceDigestResult ?? {};
  return {
    availablePage: Number(result.availablePage ?? 0),
    digests: (result.invoiceDigest ?? []) as InvoiceDigest[],
  };
}
