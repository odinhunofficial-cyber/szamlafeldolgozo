import { createAdminClient } from "@/lib/supabase/admin";
import { decrypt } from "@/lib/crypto";
import {
  NavError,
  queryInvoiceDigestPage,
  type InvoiceDigest,
  type NavCredentials,
  type NavDirection,
} from "./client";

const WINDOW_DAYS = 30; // a NAV legfeljebb 35 napos időszakot enged egy lekérdezésben
const MAX_PAGES = 50; // védelem a végtelen ciklus ellen

function isoDate(d: Date): string {
  return d.toISOString().slice(0, 10);
}

function windows(days: number): { from: string; to: string }[] {
  const out: { from: string; to: string }[] = [];
  let end = new Date();
  let remaining = days;

  while (remaining > 0) {
    const span = Math.min(remaining, WINDOW_DAYS);
    const start = new Date(end);
    start.setUTCDate(start.getUTCDate() - (span - 1));
    out.push({ from: isoDate(start), to: isoDate(end) });
    end = new Date(start);
    end.setUTCDate(end.getUTCDate() - 1);
    remaining -= span;
  }
  return out;
}

function toNum(v: string | undefined): number | null {
  if (v === undefined) return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

function toRow(companyId: string, direction: NavDirection, d: InvoiceDigest) {
  const net = toNum(d.invoiceNetAmount);
  const vat = toNum(d.invoiceVatAmount);

  return {
    company_id: companyId,
    source: "nav",
    direction: direction === "OUTBOUND" ? "outgoing" : "incoming",
    invoice_number: d.invoiceNumber ?? null,
    issue_date: d.invoiceIssueDate ?? null,
    supplier_name: d.supplierName ?? null,
    supplier_tax_number: d.supplierTaxNumber ?? null,
    customer_name: d.customerName ?? null,
    customer_tax_number: d.customerTaxNumber ?? null,
    net_amount: net,
    vat_amount: vat,
    gross_amount: net !== null && vat !== null ? Math.round((net + vat) * 100) / 100 : null,
    currency: d.currency ?? "HUF",
    raw: d,
  };
}

// A hívó felelőssége, hogy előtte ellenőrizze: a felhasználó tagja-e a cégnek.
export async function syncCompanyInvoices(companyId: string, days: number) {
  const admin = createAdminClient();

  const { data: cred, error } = await admin
    .from("nav_credentials")
    .select("*")
    .eq("company_id", companyId)
    .maybeSingle();

  if (error) {
    console.error("nav_credentials olvasási hiba", error);
    throw new NavError("A NAV-kapcsolat adatait nem sikerült betölteni.");
  }
  if (!cred || !cred.tax_number) {
    throw new NavError("Még nincs beállítva a NAV-kapcsolat ennél a cégnél.");
  }

  let creds: NavCredentials;
  try {
    creds = {
      login: decrypt(cred.login_enc),
      passwordHash: decrypt(cred.password_enc),
      signatureKey: decrypt(cred.signature_key_enc),
      taxNumber: cred.tax_number,
      environment: cred.environment,
    };
  } catch (e) {
    console.error("NAV-adatok visszafejtési hiba", e);
    throw new NavError("A mentett NAV-adatok nem olvashatók. Add meg őket újra.");
  }

  const rows: ReturnType<typeof toRow>[] = [];
  const directions: NavDirection[] = ["OUTBOUND", "INBOUND"];

  for (const direction of directions) {
    for (const w of windows(days)) {
      let page = 1;
      while (page <= MAX_PAGES) {
        const res = await queryInvoiceDigestPage(creds, direction, w.from, w.to, page);
        for (const d of res.digests) rows.push(toRow(companyId, direction, d));
        if (page >= res.availablePage) break;
        page++;
      }
    }
  }

  let inserted = 0;
  for (let i = 0; i < rows.length; i += 200) {
    const chunk = rows.slice(i, i + 200);
    // ignoreDuplicates: a már feldolgozott számlák állapotát és kategóriáját nem írjuk felül
    const { data, error: upsertError } = await admin
      .from("invoices")
      .upsert(chunk, { onConflict: "company_id,direction,invoice_number", ignoreDuplicates: true })
      .select("id");

    if (upsertError) {
      console.error("invoices mentési hiba", upsertError);
      throw new NavError("A számlák mentése az adatbázisba nem sikerült.");
    }
    inserted += data?.length ?? 0;
  }

  await admin
    .from("nav_credentials")
    .update({ last_synced_at: new Date().toISOString() })
    .eq("company_id", companyId);

  return { fetched: rows.length, inserted };
}
