import { createCipheriv, createDecipheriv, randomBytes } from "node:crypto";

// AES-256-GCM. A kulcs: CREDENTIALS_ENCRYPTION_KEY (32 bájt, base64).
// Előállítás: openssl rand -base64 32

function getKey(): Buffer {
  const b64 = process.env.CREDENTIALS_ENCRYPTION_KEY;
  if (!b64) throw new Error("Hiányzik a CREDENTIALS_ENCRYPTION_KEY környezeti változó.");
  const key = Buffer.from(b64, "base64");
  if (key.length !== 32) throw new Error("A CREDENTIALS_ENCRYPTION_KEY pontosan 32 bájt (base64) legyen.");
  return key;
}

export function encrypt(plain: string): string {
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", getKey(), iv);
  const enc = Buffer.concat([cipher.update(plain, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return [iv, tag, enc].map((b) => b.toString("base64")).join(".");
}

export function decrypt(payload: string): string {
  const [iv, tag, enc] = payload.split(".").map((p) => Buffer.from(p, "base64"));
  const decipher = createDecipheriv("aes-256-gcm", getKey(), iv);
  decipher.setAuthTag(tag);
  return Buffer.concat([decipher.update(enc), decipher.final()]).toString("utf8");
}
