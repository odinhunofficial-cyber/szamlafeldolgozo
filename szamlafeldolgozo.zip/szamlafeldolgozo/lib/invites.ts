import type { User } from "@supabase/supabase-js";
import { createAdminClient } from "@/lib/supabase/admin";

// A meghívók beváltása. Csak megerősített e-mail-címmel rendelkező felhasználónál működik,
// különben bárki hozzáférést szerezhetne egy másik e-mail-címre szóló meghívóhoz.
export async function claimInvites(user: User): Promise<void> {
  if (!user.email || !user.email_confirmed_at) return;

  const admin = createAdminClient();
  const { data: invites } = await admin
    .from("company_invites")
    .select("id, company_id, role")
    .eq("email", user.email.toLowerCase());

  if (!invites || invites.length === 0) return;

  for (const invite of invites) {
    const { error } = await admin
      .from("company_members")
      .upsert(
        { company_id: invite.company_id, user_id: user.id, role: invite.role },
        { onConflict: "company_id,user_id", ignoreDuplicates: true }
      );

    if (error) {
      console.error("Meghívó beváltási hiba", error);
      continue;
    }
    await admin.from("company_invites").delete().eq("id", invite.id);
  }
}
