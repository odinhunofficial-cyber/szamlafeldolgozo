export type FormState = { error?: string; info?: string };

export type UploadResult =
  | { ok: true; invoiceNumber: string | null; warning?: string }
  | { ok: false; error: string };
