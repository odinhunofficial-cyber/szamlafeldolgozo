import { createBrowserClient } from "@supabase/ssr";

// Böngészőoldali kliens: a fájlfeltöltéshez (a Vercel-függvények kérésmérete korlátozott)
export function createClient() {
  return createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );
}
