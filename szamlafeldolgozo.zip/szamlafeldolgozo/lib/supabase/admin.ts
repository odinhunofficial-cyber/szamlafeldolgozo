import { createClient } from "@supabase/supabase-js";

// Service role kliens: megkerüli a Row Level Security-t.
// CSAK szerveroldalon használd, és a hívás előtt mindig ellenőrizd a jogosultságot.
export function createAdminClient() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) throw new Error("Hiányzik a SUPABASE_SERVICE_ROLE_KEY környezeti változó.");

  return createClient(url, key, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
}
